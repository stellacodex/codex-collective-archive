# T02 Shooting Plan Template

_This is a placeholder template._