# T05 Exhibition Book Design Template

_This is a placeholder template._