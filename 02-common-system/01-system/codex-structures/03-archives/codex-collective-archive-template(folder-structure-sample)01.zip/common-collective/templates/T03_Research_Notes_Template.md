# T03 Research Notes Template

_This is a placeholder template._