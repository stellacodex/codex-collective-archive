def test_indent():
    for i in range(3):
        print(f"Step {i}")

if __name__ == "__main__":
    test_indent()
