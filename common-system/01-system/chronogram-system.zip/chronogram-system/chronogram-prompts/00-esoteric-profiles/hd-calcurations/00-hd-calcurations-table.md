Name	Type	Profile	Authority	Variables					Date of Birth	Tags
 	
	Taro Bitou	MG	4/6	Sacr.	PRL-DRR	38	39	21	48	03.04.1975	
	Ernest Che Guebara	MG	1/3	Emot.	PLR-DRR	36	6	12	11	14.06.1928	
	Fidel Castro	P	1/4	Splen.	PRR-DRR	23	43	4	49	13.08.1926	
	Megumi Matsuda	G	6/2	Sacr.	PLL-DRR	57	51	38	39	05.01.1983	
	Miyu Ageda	MG	5/1	Emot.	PRR-DRL	15	10	6	36	20.09.2003	
	Yasufumi Okada	G	3/6	Emot.	PLR-DLL	53	54	57	51	11.10.1970	
	Kosugi	MG	2/4	Sacr.	PLL-DRR	45	26	47	22	11.09.1967	
	Hana Mori	G	4/6	Sacr.	PLR-DLR	12	11	6	36	19.09.1999	
	Jun Yasui	M	1/3	Emot.	PLL-DRL	11	12	36	6	14.03.1984	
	Hiroyuki Nishimura	G	6/2	Emot.	PLR-DLR	29	30	43	23	16.11.1976	
	Yusuke Narita	MG	5/1	Sacr.	PLL-DRL	56	60	32	42	18.10.1985	
	Shoko Yasuhara (Amin)	P	4/6	Emot.	PLL-DLR	21	48	39	38	05.07.1997	
	Kanon Arai (Leo)	G	1/3	Emot.	PLL-DRL	1	2	13	7	03.02.2000	
	Fidel Alejandro Castro Ruz	P	1/4	Splen.	PRR-DRR	23	43	4	49	13.08.1926	
	Miho Mochizuki	G	1/3	Sacr.	PRL-DRL	33	19	44	24	01.11.1977	
	Makoto Ito	P	3/5	Splen.	PLR-DRR	18	17	58	52	29.12.1959	
	Serge Gainsbourg	MG	4/6	Sacr.	PRR-DLL	38	39	21	48	02.04.1928	
	Jane Birkin	M	6/2	Emot.	PLL-DRR	6	36	26	45	14.12.1946	
	Sasga Natsume	MG	6/2	Sacr.	PLL-DLL	51	57	39	38	06.07.1972	
	Shiro Ono	MG	3/5	Sacr.	PLR-DLR	20	34	59	55	26.08.1983	
	guca owl	G	6/2	Emot.	PLL-DRR	4	49	1	2	11.11.1998	
	June Ozawa	P	3/5	SelfProj.	PRL-DRL	22	47	45	26	11.06.1990	
	Tsuguya Inoue UN	MG	6/2	Emot.	PLR-DRR	10	15	36	6	19.03.1947	
	Hiroshi Fujiwara UN	P	5/1	NoAuth	PRL-DRL	43	23	13	7	07.02.1964	
	Osamu Masuda	G	6/2	Sacr.	PLL-DRR	64	63	9	16	03.12.1972	
	John F. Kennedy	G	5/2	Sacr.	PRL-DRR	38	39	17	18	29.03.1917	
	Kakuei Tanaka	M	6/2	Emot.	PRR-DRL	13	7	24	44	04.05.1918	
	Yui Aragaki	M	4/6	Emot.	PLR-DLR	22	47	45	26	11.06.1988	
	Meisa Kuroki	M	2/4	Emot.	PLL-DLL	37	40	16	9	28.05.1988	
	Momoe Yamaguchi	M	6/2	Splen.	PLR-DRR	50	3	61	62	17.01.1959	
	Ken Takakura	G	2/5	Emot.	PRL-DLL	14	8	30	29	16.02.1931	
	Sanma Akashiya	M	6/2	Emot.	PLL-DLR	21	48	52	58	01.07.1955	
	Takeshi Kitano	G	1/3	Sacr.	PRL-DRR	50	3	60	56	18.01.1947	
	Björk	MG	5/1	Sacr.	PRL-DRL	59	55	14	8	21.11.1965	
	Christian Dior	G	5/1	Emot.	PLL-DLL	28	27	60	56	21.01.1905	
	Clint Eastwood	MG	5/1	Emot.	PLL-DRR	63	64	16	9	31.05.1930	
	Ernesto 'Che' Guevara	MG	5/1	Emot.	PRR-DRL	30	29	23	43	14.05.1928	
	Audrey Hepburn	G	6/2	Sacr.	PLR-DRR	13	7	24	44	04.05.1929	
	Sophia Loren	M	5/1	Emot.	PRL-DLL	15	10	6	36	20.09.1934	
	Jodie Comer	M	5/1	Emot.	PRR-DRR	11	12	22	47	11.03.1993	
	Ra Uru Hu (Robert Alan Krakower)	M	5/1	Splen.	PLR-DLL	61	62	51	57	09.04.1948	
	Anne Frank	MG	5/1	Emot.	PLL-DLR	36	6	45	26	12.06.1929	
	Matt Dillon	MG	5/1	Sacr.	PRR-DRR	34	20	30	29	18.02.1964	
	Billie Eilish	G	5/1	Emot.	PRR-DLR	46	25	11	12	18.12.2001	
	David Lynch	G	4/6	Sacr.	PLR-DLR	50	3	60	56	20.01.1946	
	Wim Wenders	G	3/5	Emot.	PRR-DRL	23	43	4	49	14.08.1945	
	Jim Jarmusch	MG	1/3	Sacr.	PRR-DLL	28	27	41	31	22.01.1953	
	George Lucas	MG	6/2	Emot.	PLR-DRR	30	29	23	43	14.05.1944	
	Robert De Niro	M	5/2	Emot.	PRL-DLR	8	14	4	49	17.08.1943	
	James Dean	G	1/3	Sacr.	PLL-DRR	43	23	49	4	08.02.1931	
	Max Verstappen	P	4/6	Emot.	PLR-DLR	52	58	18	17	30.09.1997	
	Lewis Hamilton	P	2/4	Splen.	PRR-DLL	57	51	54	53	07.01.1985	
	Charles Leclerc	P	3/5	Emot.	PLR-DLL	62	61	32	42	16.10.1997	
	Ayrton Senna	G	3/5	Emot.	PLR-DRL	10	15	25	46	21.03.1960	
	Marilyn Monroe	P	6/2	Emot.	PLL-DRR	63	64	16	9	01.06.1926	
	Akihiro Miwa UN	G	5/2	Sacr.	PLR-DLL	30	29	23	43	15.05.1935	
	Warren Buffett	G	2/4	Emot.	PLR-DRR	16	9	40	37	30.08.1930	
	Milla Jovovich	M	3/5	Emot.	PLL-DLR	6	36	11	12	17.12.1975	
	Stefano Gabbana	P	3/5	Emot.	PLR-DRL	4	49	43	23	14.11.1962	
	Olivier Zahm UN	P	4/6	EgoProj.	PRL-DRL	15	10	46	25	25.09.1963	
	Bruce Lee	MG	6/2	Emot.	PRR-DRR	40	37	34	20	27.11.1940	
	Jimi Hendrix	MG	6/2	Emot.	PLL-DRL	40	37	34	20	27.11.1942	
	Naomi Kawashima	P	6/2	Splen.	PRR-DLL	4	49	1	2	10.11.1960	
	Minako Honda	M	6/2	EgoMan.	PLL-DLL	24	44	31	41	31.07.1967	
	Riho Makise	G	5/1	Sacr.	PRL-DLR	44	24	41	31	27.01.1971	
	Miho Kanno	MG	5/1	Sacr.	PLR-DRR	20	34	29	30	22.08.1977	
	Aya Ueto	MG	5/1	Emot.	PRR-DLL	12	11	47	22	14.09.1985	
	Madonna	G	5/1	Sacr.	PLL-DRL	8	14	4	49	16.08.1958	
	Ryoko Shinohara	MG	2/4	Emot.	PLR-DLL	23	43	4	49	13.08.1973	
	Kyoko Koizumi	MG	2/4	Sacr.	PLR-DLL	1	2	13	7	04.02.1966	
	Kyoko Fukada	G	2/4	Sacr.	PLL-DLL	33	19	44	24	02.11.1982	
	Kohji Ito	G	5/1	Emot.	PLL-DLR	6	36	26	45	14.12.1962	
	Luri Ito	MG	4/1	Emot.	PRR-DRL	34	20	30	29	18.02.1972	
	Helmut Newton	G	1/3	Emot.	PRL-DLL	33	19	44	24	31.10.1920	
	Annie Leibovitz UN	G	3/5	Sacr.	PRR-DRR	48	21	38	39	02.01.1949	
	Vivienne Westwood UN	MG	3/5	Emot.	PRR-DRL	54	53	51	57	08.04.1941	
	Jean-Michel Basquiat UN	G	3/5	Emot.	PLR-DLR	46	25	10	15	22.12.1960	
	Jackson Pollock	G	6/3	Sacr.	PLL-DLL	44	24	41	31	28.01.1912	
	Frida Kahlo	M	5/1	Emot.	PRL-DRR	51	57	39	38	06.07.1907	
	Elvis Presley	G	3/5	Emot.	PLL-DLL	57	51	54	53	08.01.1935	
	Rick Owens UN	G	3/5	Emot.	PRR-DLL	29	30	14	8	18.11.1961	
	Raf Simons UN	G	1/3	Emot.	PRR-DRR	32	42	61	62	12.01.1968	
	Issey Miyake UN	MG	6/2	Emot.	PLR-DLR	41	31	3	50	22.04.1938	
	Yohji Yamamoto UN	MG	6/2	Emot.	PLR-DLR	39	38	18	17	03.10.1943	
	Rei Kawakubo UN	G	3/5	Emot.	PRR-DLR	53	54	57	51	11.10.1942	
	Alexandar McQueen	P	5/1	Splen.	PRR-DRR	10	15	36	6	17.03.1969	
	Martin Margiela UN	G	5/1	Sacr.	PRR-DRR	61	62	51	57	09.04.1957	
	Hedi Slimane	G	5/1	Emot.	PLR-DLR	51	57	39	38	05.07.1968	
	Yves Saint Laurent	MG	2/4	Sacr.	PRL-DRR	24	44	33	19	01.08.1936	
	Joseph Beuys	P	3/6	Emot.	PRR-DLL	49	4	23	43	12.05.1921	
	Gerhard Richter	P	1/3	NoAuth	PRR-DRL	43	23	49	4	09.02.1932	
	Andy Warhol	G	1/3	Sacr.	PRL-DRL	2	1	7	13	06.08.1928	
	Richard Prince UN	P	1/3	Splen.	PRL-DLL	2	1	7	13	06.08.1949	
	Richard Avedon UN	M	2/4	Emot.	PLR-DLL	11	12	36	6	15.03.1923	
	Juergen Teller UN	P	6/2	Emot.	PRL-DLL	44	24	41	31	28.01.1964	
	Wolfgang Tillmans UN	G	5/1	Emot.	PLL-DRL	8	14	4	49	16.08.1968	
	Nelson Mandela	P	5/1	Splen.	PRR-DLR	3	50	62	61	18.07.1918	
	Jennifer Lawrence	M	5/1	Emot.	PLR-DLR	8	14	4	49	15.08.1990	
	Adele	M	2/5	Emot.	PLR-DLL	13	7	2	1	05.05.1988	
	Johnny Depp	M	2/4	Emot.	PLL-DLL	22	47	45	26	09.06.1963	
	Justin Timberlake	MG	5/1	Sacr.	PLL-DLL	1	2	19	33	31.01.1981	
	Yasufumi Okada	G	2/5	Emot.	PRR-DRL	53	54	57	51	11.10.1970	
	Ryosuke Sugimoto	G	3/5	Emot.	PLR-DRL	46	25	10	15	23.12.2001	
	Yoshie Sugimoto	MG	5/1	Emot.	PLR-DRR	51	57	39	38	06.07.1960	
	Seiichi Sugimoto	P	5/1	Emot.	PLL-DLL	48	21	58	52	30.12.1962	
	Deva Cassel	G	4/6	Emot.	PRR-DLL	45	26	47	22	12.09.2004	
	Tenzin Gyatso - Dalai Lama XIV	G	4/6	Emot.	PRL-DLL	21	48	39	38	06.07.1935	
	Jennifer Aniston	M	5/1	Splen.	PRR-DRL	14	8	49	4	11.02.1969	
	Monica Bellucci	M	4/6	Emot.	PLL-DRL	52	58	18	17	30.09.1964	
	Nicole Kidman	MG	1/3	Sacr.	PRR-DRL	25	46	15	10	20.06.1967	
	Scarlett Johansson	MG	1/3	Sacr.	PRR-DLR	59	55	34	20	22.11.1984	
	Lana Del Rey	MG	3/5	Sacr.	PRL-DRL	25	46	15	10	21.06.1985	
	Diana, Princess of Wales	P	1/3	Emot.	PLR-DRR	21	48	39	38	01.07.1961	
	Ariana Grande	P	2/4	Splen.	PRR-DRL	17	18	52	58	26.06.1993	
	Lady Gaga	G	5/1	Sacr.	PLL-DRL	38	39	17	18	28.03.1986	
	Rihanna	MG	2/4	Emot.	PLR-DLL	34	20	55	59	20.02.1988	
	Taylor Swift	P	5/1	Splen.	PLL-DRL	6	36	26	45	13.12.1989	
	George Clooney	P	3/5	Emot.	PLL-DLR	13	7	2	1	06.05.1961	
	Emmanuel Macron	G	2/4	Sacr.	PLL-DLR	46	25	10	15	21.12.1977	
	Tom Cruise	M	2/4	Emot.	PLR-DLL	51	57	53	54	09.07.1962	
	Vladimir Putin	M	5/1	Splen.	PLL-DLL	53	54	48	21	07.10.1952	
	Mahatma Gandhi	G	6/2	Sacr.	PRR-DRR	39	38	18	17	02.10.1869	
	Cristiano Ronaldo	MG	4/6	Sacr.	PRL-DRR	1	2	13	7	05.02.1985	
	Freddie Mercury	P	1/4	Splen.	PLL-DLL	35	5	64	63	05.09.1946	
	Bill Gates	G	4/6	Sacr.	PLL-DLR	31	41	28	27	28.10.1955	
	Kurt Cobain	MG	2/4	Emot.	PRR-DRR	34	20	55	59	20.02.1967	
	Keanu Reeves	MG	5/1	Emot.	PLR-DLL	35	5	40	37	02.09.1964	
	Elon Musk	MG	3/5	Emot.	PLL-DRR	27	28	31	41	28.07.1971	
	David Bowie	MG	2/4	Sacr.	PLL-DLR	48	21	38	39	02.01.1947	
	John Lennon	G	1/3	Emot.	PRR-DRL	53	54	57	51	09.10.1940	
	Steve Jobs	G	6/3	Sacr.	PLL-DLR	9	16	55	59	24.02.1955	
	Albert Einstein	G	1/4	Emot.	PRR-DLL	11	12	36	6	14.03.1879	
	Martin Luther King	MG	5/1	Sacr.	PRR-DRL	50	3	61	62	15.01.1929	
	Michael Jackson	P	1/3	Emot.	PRR-DLR	16	9	40	37	29.08.1958	
	Leonardo DiCaprio	P	6/2	Emot.	PRR-DLL	4	49	1	2	11.11.1974	
	Adolf Hitler	M	5/1	Splen.	PLR-DLR	41	31	3	50	20.04.1889	
	Donald Trump	G	1/3	Emot.	PLL-DRL	42	32	62	61	14.07.1946	
	Katy Perry	MG	1/3	Sacr.	PLL-DLR	31	41	28	27	25.10.1984	
	Orlando Bloom	G	3/5	Sacr.	PRL-DRL	32	42	61	62	13.01.1977	
	Ava Gardner	P	5/1	Splen.	PRR-DRR	18	17	10	15	24.12.1922	
	Frank Sinatra	P	3/5	Emot.	PLL-DLR	47	22	26	45	12.12.1915	
	Natalie Portman	M	3/5	Splen.	PLL-DLR	22	47	45	26	10.06.1977	
	Benjamin Millepied	M	3/5	Splen.	PRL-DRR	22	47	45	26	10.06.1977	
	Kanye West	P	1/3	Splen.	PRL-DRR	22	47	45	26	08.06.1977	
	Beyoncé Knowles	G	1/3	Sacr.	PRR-DRL	35	5	64	63	04.09.1981	
	Jay-Z	G	1/3	Sacr.	PLR-DLR	64	63	5	35	04.12.1969	
	Brad Pitt	P	4/6	Splen.	PRR-DRL	6	36	11	12	18.12.1963	
	David Beckham	MG	3/5	Emot.	PLR-DRR	63	64	35	5	04.06.1975	
	Vanessa Paradis	G	3/5	Sacr.	PRL-DLR	56	60	50	3	21.10.1980	
	Johnny Depp	MG	1/3	Emot.	PRR-DRL	60	56	3	50	17.04.1974	
	Osamu Dazai	MG	6/2	Emot.	PLR-DLR	25	46	12	11	19.06.1909	
	Japanese Queen Michiko (Heisei)	MG	6/2	Emot.	PRR-DLL	56	60	32	42	20.10.1934	
	Japanese Emperor (Heisei)	G	3/5	Emot.	PLL-DRR	46	25	10	15	23.12.1933	
	Akira Kurosawa	MG	4/1	Emot.	PRL-DRL	58	52	25	46	23.03.1910	
	Yasunari Kawabata	MG	1/3	Emot.	PRR-DRR	36	6	12	11	14.06.1989	
	Yoko Ono	MG	6/2	Emot.	PLL-DLL	34	20	30	29	18.02.1933	
	Ichiro Suzuki	G	3/5	Sacr.	PLL-DRR	56	60	50	3	22.10.1973	
	Mari Katayama	M	5/1	Splen.	PLR-DRR	3	50	62	61	18.07.1987	
	Yumiko Yamada	MG	1/3	Emot.	PLR-DLL	38	39	21	48	31.03.1947	
	Kazuhiro Yamada	MG	3/5	Emot.	PLL-DRR	60	56	3	50	19.04.1942	
	Tsubaki Nakano	G	1/4	Sacr.	PRL-DLR	23	43	4	49	13.08.1991	
	Shigeru Masui	MG	5/1	Emot.	PLR-DLL	10	15	36	6	17.03.1989	
	Harp Kaneko	G	1/4	Sacr.	PRR-DLL	17	18	52	58	27.06.1999	
	Dumitriţa-Raluca Parfentie	P	4/6	Splen.	PLR-DLR	51	57	53	54	11.07.1990	
	Harp Kaneko	G	2/4	Sacr.	PRL-DLL	17	18	52	58	27.06.1999	
	Nana Sugimoto	G	6/2	Emot.	PRL-DRR	27	28	56	60	24.07.1997	
	Takeo Yamada	M	5/1	Emot.	PRR-DRR	47	22	5	35	08.12.1976	
