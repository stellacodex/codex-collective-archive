#### metaphysical-profile-takeo-yamada-mbti

名前：山田　岳男（やまだ　たけお）
生年月日：1976年12月8日
旧暦年月： 1976年10月18日
出生時間： 01:38AM
出生地：釧路、北海道
年干支：丙辰
時支:丑
陰陽: 陽男 / 五行局：木三局

## MBTI
ENTJ-A, sometimes INTJ-A
