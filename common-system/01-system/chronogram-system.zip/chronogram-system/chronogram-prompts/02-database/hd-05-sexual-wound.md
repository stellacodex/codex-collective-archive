# 💔 HD Sexual Wound — 性的傷と関係性の構造

## 内容構成（予定）

- Venus Sequenceの起点
- Attraction Sphere
- Core Woundの分類（Genetic／Energetic）
- センター別の性・関係性への影響

## 解説方針

- Gene KeysのVenus Sequenceをベースに、HDとのマッピングから解釈。
- タイプごとの性欲傾向／トラウマパターン／反応傾向なども明記。
