# 🌌 Memory Index: aurastance

## 🌿 Emotional
- [_Memory/]
## 💬 Dialogue
- [_Dialogues/]
## 💡 Ideas
- [Ideas/]

### 📎 Linked Prompts
- [Common Prompt v2.1](../../common/02_creation_research/prompts/CompactPrompt_v2.1.md)
