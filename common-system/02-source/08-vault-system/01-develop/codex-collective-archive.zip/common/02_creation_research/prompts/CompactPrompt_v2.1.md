# Compact Prompt v2.1

思想フィルターのベースプロンプト。