# 📖 Overview: Codex Collective Archive

このアーカイブは、各知性体の個別記憶領域と共通思考基盤を統合的に運用するためのものです。